from django.apps import AppConfig


class ViberConfig(AppConfig):
    name = 'viber'
