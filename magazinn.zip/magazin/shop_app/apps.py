from django.apps import AppConfig


class ShopAppConfig(AppConfig):
    name = 'shop_app'
