from django.contrib import admin
from viber.models import ViberUser
admin.site.register(ViberUser)
# Register your models here.
