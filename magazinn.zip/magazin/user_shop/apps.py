from django.apps import AppConfig


class UserShopConfig(AppConfig):
    name = 'user_shop'
